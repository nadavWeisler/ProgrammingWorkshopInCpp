#include "Dense.h"

/**
 * Inits a new layer with given parameters
 * @param weightMat			Matrix
 * @param _biasMat			Matrix
 * @param _activationType	ActivationType
 */
Dense::Dense(const Matrix &weightMat, const Matrix &_biasMat, ActivationType _activationType)
{
	this->_weightMatrix = weightMat;
	this->_bias = _biasMat;
	this->_activationType = _activationType;
}

/**
 * Returns the weights of this layer
 * @return Weights matrix
 */
Matrix Dense::getWeights() const
{
	return this->_weightMatrix;
}

/**
 * Returns the bias of this layer
 * @return 	Bias matrix
 */
Matrix Dense::getBias() const
{
	return this->_bias;
}

/**
 * Returns the activation function of this layer
 * @return	Activation
 */
Activation Dense::getActivation() const
{
	Activation currentActivation(this->_activationType);
	return currentActivation;
}

/**
 * Parenthesis operator override,
 * Applies the layer on inputMatrix and returns output matrix
 * @param inputMatrix		Matrix
 * @return					Matrix
 */
Matrix Dense::operator()(const Matrix& inputMatrix) const
{
	return this->getActivation()((getWeights() * inputMatrix) + getBias());
}


