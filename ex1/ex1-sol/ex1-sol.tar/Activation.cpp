#include <cmath>
#include "Activation.h"

/**
 *	Constructor
 *	Accepts activation type
 * @param actType ActivationType
 */
Activation::Activation(ActivationType actType)
{
	this->_activationType = actType;
}

/**
 *	Returns this activation’s type
 * @return	ActivationType
 */
ActivationType Activation::getActivationType()
{
	return this->_activationType;
}

/**
 *	Parenthesis operator override,
 *	Applies activation function on input.
 * @param inputMatrix	Matrix
 * @return	Matrix
 */
Matrix Activation::operator()(const Matrix& inputMatrix)
{
	if (this->_activationType == Relu)
	{
		return this->relu(inputMatrix);
	}
	else
	{
		return this->softmax(inputMatrix);
	}
}

/**
 * Relu activation
 * @param matrix 	Matrix
 * @return 			Matrix
 */
Matrix Activation::relu(const Matrix& matrix)
{
	Matrix newMatrix = Matrix(matrix);
    for (int i = 0; i < newMatrix.getRows() * newMatrix.getCols(); ++i)
    {
        if (newMatrix[i] < 0)
        {
			newMatrix[i] = 0;
        }
    }
    return newMatrix;
}

/**
 * Softmax activation
 * @param matrix 	Matrix
 * @return 			Matrix
 */
Matrix Activation::softmax(const Matrix& matrix)
{
	Matrix newMatrix = Matrix(matrix);
    float count = 0;
    for (int i = 0; i < matrix.getRows(); ++i)
    {
		newMatrix[i] = std::exp(newMatrix[i]);
		count += newMatrix[i];
    }
	newMatrix = (1 / count) * newMatrix;

    return newMatrix;
}
