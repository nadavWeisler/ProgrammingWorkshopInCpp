//
// Created by Weisl on 6/14/2020.
//

#ifndef EX1_SOL__MLPNETWORK_H_
#define EX1_SOL__MLPNETWORK_H_

class MlpNetwork
{

};

#endif //EX1_SOL__MLPNETWORK_H_
