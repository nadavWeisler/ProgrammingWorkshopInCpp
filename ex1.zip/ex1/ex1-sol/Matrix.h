//
// Created by Weisl on 6/14/2020.
//

#ifndef EX1_SOL__MATRIX_H_
#define EX1_SOL__MATRIX_H_

class Matrix
{
	Matrix(int rows, int cols)
	{

	}

	Matrix();

	~Matrix();

	getRows();

	getCols();

	vectorize();

	plainPrint();

	std::ostream& operator<<(std::ostream& os, const T& obj);
};

#endif //EX1_SOL__MATRIX_H_
