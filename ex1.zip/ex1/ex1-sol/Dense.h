//
// Created by Weisl on 6/14/2020.
//

#ifndef EX1_SOL__DENSE_H_
#define EX1_SOL__DENSE_H_

class Dense
{

};

#endif //EX1_SOL__DENSE_H_
